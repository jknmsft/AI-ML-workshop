# AI/ML_workshop
Notebooks for Microsoft AI/ML workshop November 2023
